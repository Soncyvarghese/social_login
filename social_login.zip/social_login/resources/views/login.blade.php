<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		@include('header')
	</head>
	<body>
		<form>
    	@csrf
			<div class="card" style="width: 18rem;margin: auto">
				<img src="{{URL::asset('/images/technology.jpg')}}" alt="profile Pic" height="200" width="287">
	 		<div>
			<label>Mobile No :</label>
    		@if(!empty($payment))
    		<label>+91-9526864560</label>
			@else
			<label>xx-xxxxxxxxxx</label>
    		@endif
	</div>
	@if(!empty($payment))
	<a href="{{ url('') }}" class="btn btn-warning"> Refresh Page</a>
	@else	
	<button type="button"  class="btn btn-primary" id="button1">Click to unlock</button>
	@endif
		</div>
			<div class="modal fade" id="newModal" tabindex="-1" role="dialog" aria- 
            labelledby="demoModalLabel" aria-hidden="true">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
						</div>
						<div class="modal-body">
								<a class="ml-1 btn btn-primary" href="{{ url('redirect') }}" style="margin-top: 0px !important;background: #4c6ef5;color: #ffffff;padding: 5px;border-radius:7px;" id="btn-fblogin">
        							<i class="fa fa-facebook-square" aria-hidden="true"></i> Login with Facebook
    							</a>
						</div>
					</div>
				</div>
			</div>	
		</form>		
	</body>
</html>
<script>
$(document).ready(function(){
  $("#button1").click(function(){
    $("#newModal").modal("toggle");
  });
});
</script>