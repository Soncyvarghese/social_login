<!DOCTYPE html>
<html>
@include('header')
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            @if(isset($message))
                <div class="alert alert-danger alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <strong>Error!</strong> {{ $message }}
                </div>
            @endif
            <div class="panel panel-default" style="margin-top: 30px;">
                <div class="panel-heading">
                    <h2>Pay With Razorpay</h2>
                
                    <form method="POST" action="{!!route('payment')!!}">
                        <script src="https://checkout.razorpay.com/v1/checkout.js"
                                data-key="{{ env('RAZOR_KEY') }}"
                                data-amount="1000"
                                data-buttontext="Pay Amount"
                                data-name="test"
                                data-description="Payment"
                                data-prefill.name="name"
                                data-prefill.email="email"
                                data-theme.color="#ff7529">
                        </script>
                        <input type="hidden" name="_token" value="{!!csrf_token()!!}">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
