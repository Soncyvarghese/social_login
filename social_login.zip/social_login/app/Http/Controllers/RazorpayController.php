<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Razorpay\Api\Api;
use App\Models\User;
use App\Models\UserPayment;
use Session;
use Redirect;
use Auth;

class RazorpayController extends Controller
{
    public function payment(Request $request)
    {      
        try 
        {
            $input = $request->all();        
            $api = new Api(env('RAZOR_KEY'), env('RAZOR_SECRET'));
            $payment = $api->payment->fetch($input['razorpay_payment_id']);

            if(count($input)  && !empty($input['razorpay_payment_id'])) 
            {
                $payment = UserPayment::create([
                        'razorpay_id' =>$input['razorpay_payment_id'],
                        'user_id' => Auth::id(),
                        'amount'=> $payment['amount']/100
                ]);
                return view('login')->with(['payment'=>1]);
            }else{
                return Redirect::to('/dashboard')->with('message', 'Payment Failed');
            }          
        }
        catch (\Exception $e) 
        {
            return $e->getMessage();
        }  
    }
}