<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Exception;
use App\Models\User;
Use View;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;

class LoginController extends Controller
{
    public function redirectFacebook()
    {
       
        return Socialite::driver('facebook')->redirect();
    }

    public function index()
    {
       
        return View::make('login');
    }

    public function facebookCallback()
    {
        try {
            $user=Socialite::driver('facebook')->stateless()->user();
        } catch (Exception $e) {
            return redirect('/');
        }
            $userData = User::where('facebook_id', $user->id)->first();
            if(!$userData){
                $id =User::insertGetId([
                    'name' => $user->name,
                    'email' => $user->email,
                    'facebook_id'=> $user->id,
                    'created_at'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s')
                ]);
               $userData = User::where('id',$id)->first();
            }
            Auth::login($userData);
            return View::make('dashboard');
        
    }
}