<!DOCTYPE html>
<html>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(isset($message)): ?>
                <div class="alert alert-danger alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <strong>Error!</strong> <?php echo e($message); ?>

                </div>
            <?php endif; ?>
            <div class="panel panel-default" style="margin-top: 30px;">
                <div class="panel-heading">
                    <h2>Pay With Razorpay</h2>
                
                    <form method="POST" action="<?php echo route('payment'); ?>">
                        <script src="https://checkout.razorpay.com/v1/checkout.js"
                                data-key="<?php echo e(env('RAZOR_KEY')); ?>"
                                data-amount="1000"
                                data-buttontext="Pay Amount"
                                data-name="test"
                                data-description="Payment"
                                data-prefill.name="name"
                                data-prefill.email="email"
                                data-theme.color="#ff7529">
                        </script>
                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH /var/www/html/social_login/resources/views/dashboard.blade.php ENDPATH**/ ?>